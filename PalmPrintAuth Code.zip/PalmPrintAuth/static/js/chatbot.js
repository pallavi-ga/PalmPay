/**
 * PalmPay Chatbot - JavaScript for handling chatbot interactions
 */
class PalmPayChatbot {
    constructor() {
        // DOM Elements
        this.chatbotToggle = document.getElementById('chatbot-toggle');
        this.chatbotWindow = document.getElementById('chatbot-window');
        this.chatbotClose = document.getElementById('chatbot-close');
        this.chatbotMessages = document.getElementById('chatbot-messages');
        this.chatbotInput = document.getElementById('chatbot-input');
        this.chatbotSend = document.getElementById('chatbot-send');
        this.chatbotTyping = document.getElementById('chatbot-typing');
        
        // Chatbot state
        this.isOpen = false;
        
        // Bind methods to this
        this.toggleChatbot = this.toggleChatbot.bind(this);
        this.closeChatbot = this.closeChatbot.bind(this);
        this.sendMessage = this.sendMessage.bind(this);
        this.handleInputKeypress = this.handleInputKeypress.bind(this);
        
        // Initialize chatbot
        this.init();
    }
    
    /**
     * Initialize the chatbot
     */
    init() {
        // Add event listeners
        this.chatbotToggle.addEventListener('click', this.toggleChatbot);
        this.chatbotClose.addEventListener('click', this.closeChatbot);
        this.chatbotSend.addEventListener('click', this.sendMessage);
        this.chatbotInput.addEventListener('keypress', this.handleInputKeypress);
        
        // Add welcome message after a short delay
        setTimeout(() => {
            this.addBotMessage({
                message: "Hello! Welcome to PalmPay support. How can I help you with your palm-based payments today?",
                timestamp: this.getCurrentTime()
            });
        }, 1000);
    }
    
    /**
     * Toggle the chatbot visibility
     */
    toggleChatbot() {
        this.isOpen = !this.isOpen;
        
        if (this.isOpen) {
            this.chatbotWindow.classList.add('active');
            this.chatbotWindow.style.display = 'flex';
            this.chatbotToggle.innerHTML = '<i class="fas fa-times"></i>';
            this.chatbotInput.focus();
        } else {
            this.chatbotWindow.classList.remove('active');
            setTimeout(() => {
                this.chatbotWindow.style.display = 'none';
            }, 300);
            this.chatbotToggle.innerHTML = '<i class="fas fa-comments"></i>';
        }
    }
    
    /**
     * Close the chatbot
     */
    closeChatbot() {
        if (this.isOpen) {
            this.toggleChatbot();
        }
    }
    
    /**
     * Handle input keypress (send on Enter)
     * @param {Event} e - KeyPress event
     */
    handleInputKeypress(e) {
        if (e.key === 'Enter') {
            this.sendMessage();
        }
    }
    
    /**
     * Send a message to the chatbot
     */
    sendMessage() {
        const message = this.chatbotInput.value.trim();
        
        if (message) {
            // Add user message to chat
            this.addUserMessage({
                message: message,
                timestamp: this.getCurrentTime()
            });
            
            // Clear input
            this.chatbotInput.value = '';
            
            // Show typing indicator
            this.showTypingIndicator();
            
            // Send message to server
            this.sendMessageToServer(message);
        }
    }
    
    /**
     * Send message to server API
     * @param {string} message - Message to send
     */
    sendMessageToServer(message) {
        fetch('/api/chatbot', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message }),
        })
        .then(response => response.json())
        .then(data => {
            // Hide typing indicator
            this.hideTypingIndicator();
            
            // Add bot response to chat
            this.addBotMessage(data);
        })
        .catch(error => {
            // Hide typing indicator
            this.hideTypingIndicator();
            
            // Add error message
            this.addBotMessage({
                message: "Sorry, I'm having trouble connecting. Please try again later.",
                timestamp: this.getCurrentTime()
            });
            console.error('Chatbot error:', error);
        });
    }
    
    /**
     * Add a user message to the chat
     * @param {object} data - Message data
     */
    addUserMessage(data) {
        const messageElement = document.createElement('div');
        messageElement.className = 'chatbot-message user-message';
        
        const messageText = document.createElement('div');
        messageText.textContent = data.message;
        
        const messageTime = document.createElement('span');
        messageTime.className = 'message-time';
        messageTime.textContent = data.timestamp;
        
        messageElement.appendChild(messageText);
        messageElement.appendChild(messageTime);
        
        this.chatbotMessages.appendChild(messageElement);
        this.scrollToBottom();
    }
    
    /**
     * Add a bot message to the chat
     * @param {object} data - Message data
     */
    addBotMessage(data) {
        const messageElement = document.createElement('div');
        messageElement.className = 'chatbot-message bot-message';
        
        const messageText = document.createElement('div');
        messageText.textContent = data.message;
        
        const messageTime = document.createElement('span');
        messageTime.className = 'message-time';
        messageTime.textContent = data.timestamp;
        
        messageElement.appendChild(messageText);
        messageElement.appendChild(messageTime);
        
        this.chatbotMessages.appendChild(messageElement);
        this.scrollToBottom();
    }
    
    /**
     * Show typing indicator
     */
    showTypingIndicator() {
        this.chatbotTyping.style.display = 'block';
        this.scrollToBottom();
    }
    
    /**
     * Hide typing indicator
     */
    hideTypingIndicator() {
        this.chatbotTyping.style.display = 'none';
    }
    
    /**
     * Scroll to the bottom of the messages
     */
    scrollToBottom() {
        this.chatbotMessages.scrollTop = this.chatbotMessages.scrollHeight;
    }
    
    /**
     * Get current time in HH:MM format
     * @returns {string} Current time
     */
    getCurrentTime() {
        const now = new Date();
        let hours = now.getHours();
        let minutes = now.getMinutes();
        
        // Add leading zero if needed
        hours = hours < 10 ? '0' + hours : hours;
        minutes = minutes < 10 ? '0' + minutes : minutes;
        
        return `${hours}:${minutes}`;
    }
}

// Initialize chatbot when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Only initialize if chatbot elements exist
    if (document.getElementById('chatbot-toggle')) {
        const chatbot = new PalmPayChatbot();
    }
});