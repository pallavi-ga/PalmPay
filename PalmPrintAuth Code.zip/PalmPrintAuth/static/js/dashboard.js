/**
 * Dashboard.js - JavaScript for dashboard functionality
 */

class Dashboard {
    constructor() {
        this.charts = {};
        this.data = {
            authStats: null,
            userStats: null
        };
    }

    /**
     * Initialize dashboard
     */
    init() {
        this.initEventListeners();
    }

    /**
     * Initialize event listeners
     */
    initEventListeners() {
        // Example: Add event listener for a refresh button
        const refreshBtn = document.getElementById('refresh-stats');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.refreshStats());
        }
    }

    /**
     * Create authentication statistics chart
     * @param {string} elementId - Canvas element ID for the chart
     * @param {Array} data - Data for the chart [success, failure]
     */
    createAuthChart(elementId, data) {
        const ctx = document.getElementById(elementId).getContext('2d');
        
        this.charts.authChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Successful', 'Failed'],
                datasets: [{
                    data: data,
                    backgroundColor: [
                        'rgba(40, 167, 69, 0.8)',
                        'rgba(220, 53, 69, 0.8)'
                    ],
                    borderColor: [
                        'rgba(40, 167, 69, 1)',
                        'rgba(220, 53, 69, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                    },
                    title: {
                        display: true,
                        text: 'Authentication Results'
                    }
                }
            }
        });
    }

    /**
     * Create similarity score history chart
     * @param {string} elementId - Canvas element ID for the chart
     * @param {Array} labels - Labels for the chart (dates)
     * @param {Array} scores - Similarity scores
     */
    createScoreHistoryChart(elementId, labels, scores) {
        const ctx = document.getElementById(elementId);
        if (!ctx) return;
        
        this.charts.scoreChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Similarity Score',
                    data: scores,
                    backgroundColor: 'rgba(13, 110, 253, 0.2)',
                    borderColor: 'rgba(13, 110, 253, 1)',
                    borderWidth: 2,
                    tension: 0.3,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 1
                    }
                },
                plugins: {
                    title: {
                        display: true,
                        text: 'Authentication Score History'
                    }
                }
            }
        });
    }

    /**
     * Refresh dashboard statistics
     * In a real app, this would fetch updated data from the server
     */
    refreshStats() {
        // Example: In a real app, we would fetch data from the server
        console.log('Refreshing dashboard statistics...');
        
        // Show loading indicator
        this.showLoading(true);
        
        // Simulate API call delay
        setTimeout(() => {
            // Update charts with new data
            if (this.charts.authChart) {
                this.charts.authChart.data.datasets[0].data = [12, 3]; // Example new data
                this.charts.authChart.update();
            }
            
            // Hide loading indicator
            this.showLoading(false);
        }, 1000);
    }

    /**
     * Show or hide loading indicator
     * @param {boolean} show - Whether to show or hide the loading indicator
     */
    showLoading(show) {
        const loadingElement = document.getElementById('dashboard-loading');
        if (loadingElement) {
            loadingElement.style.display = show ? 'block' : 'none';
        }
    }
}

// Initialize dashboard when DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
    const dashboard = new Dashboard();
    dashboard.init();
});
