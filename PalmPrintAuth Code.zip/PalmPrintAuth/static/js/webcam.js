/**
 * Webcam.js - JavaScript library for working with webcam in the browser
 * Manages camera initialization, frame capture, and stream handling
 */

class Webcam {
    constructor(videoElement, options = {}) {
        this.videoElement = videoElement;
        this.stream = null;
        this.options = {
            width: options.width || 640,
            height: options.height || 480,
            facingMode: options.facingMode || 'environment',
            ...options
        };
    }

    /**
     * Start the webcam
     * @returns {Promise} Promise that resolves when camera is started
     */
    async start() {
        if (this.stream) {
            console.warn('Camera is already started');
            return Promise.resolve(this.stream);
        }

        try {
            this.stream = await navigator.mediaDevices.getUserMedia({
                video: {
                    facingMode: this.options.facingMode,
                    width: { ideal: this.options.width },
                    height: { ideal: this.options.height }
                }
            });
            
            this.videoElement.srcObject = this.stream;
            
            return new Promise((resolve) => {
                this.videoElement.onloadedmetadata = () => {
                    this.videoElement.play();
                    resolve(this.stream);
                };
            });
        } catch (error) {
            console.error('Error starting camera:', error);
            throw error;
        }
    }

    /**
     * Stop the webcam
     */
    stop() {
        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.videoElement.srcObject = null;
            this.stream = null;
        }
    }

    /**
     * Capture a frame from the webcam
     * @returns {String} Base64 encoded image data
     */
    captureFrame() {
        if (!this.stream) {
            throw new Error('Camera is not started');
        }

        const canvas = document.createElement('canvas');
        canvas.width = this.videoElement.videoWidth;
        canvas.height = this.videoElement.videoHeight;
        
        const context = canvas.getContext('2d');
        context.drawImage(this.videoElement, 0, 0, canvas.width, canvas.height);
        
        return canvas.toDataURL('image/jpeg');
    }

    /**
     * Check if the camera is available
     * @returns {Promise<boolean>} True if camera is available
     */
    static async isAvailable() {
        try {
            const devices = await navigator.mediaDevices.enumerateDevices();
            return devices.some(device => device.kind === 'videoinput');
        } catch (error) {
            console.error('Error checking camera availability:', error);
            return false;
        }
    }

    /**
     * Switch between front and back cameras
     */
    switchCamera() {
        // Toggle facing mode
        this.options.facingMode = this.options.facingMode === 'user' ? 'environment' : 'user';
        
        // Restart the camera with new facing mode
        this.stop();
        return this.start();
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && typeof module.exports !== 'undefined') {
    module.exports = Webcam;
}
