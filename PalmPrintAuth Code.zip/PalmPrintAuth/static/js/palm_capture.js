/**
 * Palm Capture - JavaScript for palm image capture and processing
 * Provides utilities for working with the webcam and palm images
 */

class PalmCapture {
    constructor(videoElement, overlayElement, options = {}) {
        this.videoElement = videoElement;
        this.overlayElement = overlayElement;
        this.options = {
            countdown: options.countdown || 3,
            captureDelay: options.captureDelay || 1000,
            ...options
        };
        
        this.stream = null;
        this.isCapturing = false;
        this.captureCallbacks = {
            onStart: options.onStart || (() => {}),
            onCountdown: options.onCountdown || (() => {}),
            onCapture: options.onCapture || (() => {}),
            onError: options.onError || (() => {})
        };
    }

    /**
     * Initialize the camera
     * @returns {Promise} Promise that resolves when camera is initialized
     */
    async initCamera() {
        try {
            this.stream = await navigator.mediaDevices.getUserMedia({
                video: {
                    facingMode: 'environment',
                    width: { ideal: 1280 },
                    height: { ideal: 720 }
                }
            });
            
            this.videoElement.srcObject = this.stream;
            
            return new Promise((resolve) => {
                this.videoElement.onloadedmetadata = () => {
                    this.videoElement.play();
                    resolve(this.stream);
                };
            });
        } catch (error) {
            console.error('Error initializing camera:', error);
            this.captureCallbacks.onError(error);
            throw error;
        }
    }

    /**
     * Stop the camera
     */
    stopCamera() {
        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.videoElement.srcObject = null;
            this.stream = null;
        }
    }

    /**
     * Start the palm capture process with countdown
     */
    startCapture() {
        if (this.isCapturing) return;
        
        this.isCapturing = true;
        this.captureCallbacks.onStart();
        
        // Start countdown
        let count = this.options.countdown;
        this.captureCallbacks.onCountdown(count);
        
        const countdownInterval = setInterval(() => {
            count--;
            
            if (count > 0) {
                this.captureCallbacks.onCountdown(count);
            } else {
                clearInterval(countdownInterval);
                this.capturePalm();
            }
        }, 1000);
    }

    /**
     * Capture palm image from video feed
     */
    capturePalm() {
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        
        // Set canvas dimensions to match video feed
        canvas.width = this.videoElement.videoWidth;
        canvas.height = this.videoElement.videoHeight;
        
        // Draw the current frame from the video
        context.drawImage(this.videoElement, 0, 0, canvas.width, canvas.height);
        
        // Convert to base64 image
        const imageData = canvas.toDataURL('image/jpeg');
        
        // Reset capturing flag
        this.isCapturing = false;
        
        // Call the capture callback with the image data
        this.captureCallbacks.onCapture(imageData);
    }

    /**
     * Check if palm is properly positioned in the frame
     * This is a simplified placeholder function - actual palm detection would be more complex
     * @returns {boolean} True if palm is detected in a good position
     */
    isPalmPositioned() {
        // In a real implementation, this would use computer vision to detect palm position
        // For now, this is just a placeholder
        return true;
    }

    /**
     * Add guidelines overlay to help position the palm
     * @param {string} message - Message to display in the guide
     */
    showGuidelines(message = 'Place palm here') {
        if (!this.overlayElement) return;
        
        const guideElement = document.createElement('div');
        guideElement.className = 'palm-guide';
        
        const textElement = document.createElement('span');
        textElement.className = 'palm-guide-text';
        textElement.textContent = message;
        
        guideElement.appendChild(textElement);
        this.overlayElement.appendChild(guideElement);
    }

    /**
     * Remove the guidelines overlay
     */
    hideGuidelines() {
        if (!this.overlayElement) return;
        
        const guideElement = this.overlayElement.querySelector('.palm-guide');
        if (guideElement) {
            this.overlayElement.removeChild(guideElement);
        }
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && typeof module.exports !== 'undefined') {
    module.exports = PalmCapture;
}
